package umlmaster2.metrics;

import java.util.ArrayList;
import java.util.regex.Matcher;

public class DITXMI extends MetricsXMI{
	public ArrayList<String> name;
	private final String[] searchs = new String[]{"generalization", "general"};
	public DITXMI(String context) {
		super(context);
		SearchFather();
		// TODO Auto-generated constructor stub
	}

  public void SearchFather(){
	  Matcher match = SearchTag("packagedElement", context);
      ArrayList<String> classes = new ArrayList<String>();
      name = new ArrayList<String>();
      
      while(match.find()!=false){
    	System.out.println(match.group());
    	classes.add(match.group());
    	
    	System.out.println( SearchAttr("name", match.group()));
    	name.add(SearchAttr("name", match.group()));
    	
    	System.out.print("\n"+name.get(0)) ;
      }
    	  
  }
}
