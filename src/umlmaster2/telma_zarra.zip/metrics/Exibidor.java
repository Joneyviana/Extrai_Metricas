package umlmaster2.metrics;

public interface Exibidor {
   
	public void enviarRegistro(String key ,int Value) ;
	public void atualizarRegistro(String Name) ;	
	

} 
