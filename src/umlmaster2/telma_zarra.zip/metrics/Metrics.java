package umlmaster2.metrics;

import java.util.HashMap;

public class Metrics {

public String tag;
public static Exibidor exibidor;
private String name;
public String getName() {
	return name;
}

public String ID ;
public HashMap<String,Integer> frequencia_de_names = new HashMap<>();
public void setName(String name) {
	
	if (exibidor != null){
		   
		   if(frequencia_de_names.containsKey(name)==true){
		      
			   frequencia_de_names.put(name, frequencia_de_names.get(name)+1);
			   exibidor.atualizarRegistro(name);
		   }
			else{
			 frequencia_de_names.put(name, 1);
			 exibidor.enviarRegistro(name,1);
		   }
		   
	}
   this.name = name ;
   //run();
}
	
public static void addExibidor(Exibidor exibido){
	exibidor = exibido;
	System.out.print(exibidor);
}



	
}