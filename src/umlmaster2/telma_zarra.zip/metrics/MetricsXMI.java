package umlmaster2.metrics;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.osgi.framework.internal.core.SystemBundleActivator;

public class MetricsXMI {

protected	Pattern pattern ;
protected String context;
public String[] searchs;
protected Matcher searchTag;

public MetricsXMI (String context){
	this.context = context;
}
public Matcher SearchTag(String tags , String context){
	
	pattern = Pattern.compile("(<"+ tags +"([^<>]+)(?:/>|([^/]>(.+?)?)?</?"+ tags + "/?\\s*>))",2);
	return buildmatcher(pattern, context);
	
	
}
public String testSearchonSearch() {
	// TODO Auto-generated method stub
	String context = this.context; 
	for (String find : searchs) {
		if (context.matches(find + "=")== true){
		   context = SearchAttr(find , context);
			continue;
		}
			context = SearchTag(find , context).group();
		
	}
	return context;
}
public  String  SearchAttr(String find, String context) {
	pattern = Pattern.compile(find+"\\s*=\\s*.([^\\s/>]*).(?:/>|\\s)");
	
	return buildmatcher(pattern, context).group(1).replaceAll("\"", "");
	
}
public String getContext() {
	return context;
}
public Matcher buildmatcher(Pattern pattern ,String context){
	Matcher matcher = pattern.matcher(context) ;
	matcher.find();
	
	return matcher;
	
}
}
