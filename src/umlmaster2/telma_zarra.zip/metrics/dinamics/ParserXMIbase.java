package umlmaster2.metrics.dinamics;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.regex.Matcher;

import umlmaster2.metrics.Metrics;
import umlmaster2.metrics.MetricsXMI;

public class ParserXMIbase  extends MetricsXMI{

	  private String tag;
	public ParserXMIbase(String context , String tag) {
		super(context);
		this.tag = tag ;
		SearchFather();
	}

	
	private ArrayList<Metrics> classes;
    private static Method[]  methods ;
	public ArrayList<Metrics> getClasses() {
		return classes;
	}
    
	public void SearchFather(){
		  Matcher match = SearchTag(tag, context);
	      classes = new ArrayList<Metrics>();
	      classes.add(addMetrics(match));
	      
	      while(match.find()!=false){
	       classes.add(addMetrics(match));
	    	 
	      }
	       

}
     private Metrics addMetrics(Matcher match
		){
    	 Metrics metric = new Metrics() ;
	    	metric.tag = match.group();
	    	
	    	metric.setName(SearchAttr("name", match.group()));
	    	if (Metrics.exibidor ==null)
	    	    metric.ID = SearchAttr("id", match.group());	
    	 return metric;
    	 
     }

	

	
}
