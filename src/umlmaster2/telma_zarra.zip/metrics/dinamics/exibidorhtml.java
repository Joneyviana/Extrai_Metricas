package umlmaster2.metrics.dinamics;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.table.DefaultTableModel;
import javax.swing.text.html.*;

import umlmaster2.metrics.Exibidor;

public class exibidorhtml{
  private HTMLDocument document ;
  public FileWriter arquivo ;
public exibidorhtml(String path,DefaultTableModel model) throws IOException {
	path = path.substring(0, path.length()-3)+"html";            
    arquivo = new FileWriter(path);
    arquivo.write("<html><head></head><body><table><th>name</th><th>ocorrencia</th>");
    System.out.print(model.getRowCount());
    for(int m=0;m<model.getRowCount();m++){ 
        arquivo.write("<tr><td>"+model.getValueAt(m, 0)+"</td><td>"+model.getValueAt(m, 1)+"</td></tr>");
    	
    }
    arquivo.write("</table></body></html>");
    arquivo.close();
}


}
 