package umlmaster2.metrics.dinamics;

import java.io.IOException;

import javax.swing.SwingUtilities;

import umlmaster2.metrics.ExibidorTable;
import umlmaster2.metrics.Metrics;
import umlmaster2.metrics.filelistener;
import umlmaster2.metrics.filevent;
import umlmaster2.monitor.SimpleReadFile;

public class principal {

	private static SimpleReadFile simple;
	private static ParserXMIbase base;
	private static ExibidorTable exi;

	public static void main(String[] args) throws IOException, InterruptedException {
		
	     
		  exi = new ExibidorTable();
		exi.addfilelistener(new filelistener() {
			
			@Override
			public void fileselected(filevent file) {
				try {
					simple = new SimpleReadFile(file.getNamefile());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Metrics.addExibidor(exi);
				base = new ParserXMIbase(simple.getText(),"UML:Class");
				
			}
		});
		 
	
	}

}
