package umlmaster2.metrics;

public interface filelistener {

public void fileselected(filevent file);
}
