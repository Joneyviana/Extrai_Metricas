package umlmaster2.monitor;

public interface subscribed {

}
