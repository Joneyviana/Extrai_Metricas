package umlmaster2.monitor;

public interface subscription {

public void NotifyInstance(subscribed sub); 
public subscribed ConsulteInstance(String str);
}
